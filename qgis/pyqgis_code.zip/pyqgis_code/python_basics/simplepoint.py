class Point:

    marker_size = 4

    def draw(self):
        print "drawing the point"

    def move(self, new_x, new_y):
        print "moving the point"
